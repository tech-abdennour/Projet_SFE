import glob
import os
from pathlib import Path

if os.path.exists("/app"):
    ANALYSIS_EXPORTS_DIR = Path("/app/service/analysis_exports")
else:
    ROOT_DIR = Path(__file__).resolve().parents[1]
    ANALYSIS_EXPORTS_DIR = ROOT_DIR / "service" / "analysis_exports"

IMAGE_EXTENSIONS = ("*.png", "*.jpg", "*.jpeg", "*.webp", "*.gif")

def cleanup_all_images(analysis_exports_dir=ANALYSIS_EXPORTS_DIR, dry_run=False):
    analysis_exports_dir = Path(analysis_exports_dir)
    analysis_exports_dir.mkdir(parents=True, exist_ok=True)
    deleted = []
    for extension in IMAGE_EXTENSIONS:
        for file_path in glob.glob(str(analysis_exports_dir / extension)):
            try:
                if not dry_run:
                    os.remove(file_path)
                deleted.append(file_path)
            except FileNotFoundError:
                pass
    return {
        "deleted": deleted,
        "deleted_count": len(deleted),
        "dry_run": dry_run,
    }

if __name__ == "__main__":
    result = cleanup_all_images()
    print("[CLEANUP ALL IMAGES] Résultat:")
    print(result)
